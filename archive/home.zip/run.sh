python ./src/main.py
